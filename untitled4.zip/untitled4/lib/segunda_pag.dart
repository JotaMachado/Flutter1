import 'package:untitled4/cadastro.dart';
import 'package:untitled4/main.dart';
import 'package:untitled4/variaveis.dart';
import 'package:flutter/material.dart';


class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text('New Screen')
      ),
      body: ListView.builder(
              itemCount: contatos.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text('${contatos[index]}'),
                );
              },
            ),
            floatingActionButton: FloatingActionButton(
    backgroundColor: const Color(0xff03dac6),
    foregroundColor: Colors.black,
    onPressed: () {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) =>  SecondRoute()),
      );
    },
    child: Icon(Icons.add),
    ),
    );
  }
}


