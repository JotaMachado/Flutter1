import 'package:untitled4/cadastro.dart';
final List<Cadastro>  contatos = [];
var globalIndex;