import 'package:untitled4/cadastro.dart';
List<Cadastro>  contatos = [];