import 'package:flutter/material.dart';

void main() {
  runApp( MyApp());
}

class Cadastro {
  final String nome;
  final int telefone;
  final String email;

  Cadastro(this.nome,
      this.telefone,
      this.email,
      );

  @override
  String toString() {
    return 'Cadastro{nome: $nome, telefone: $telefone, email: $email}';
  }
}

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomeScreen()
    );
  }
}

class HomeScreen extends StatelessWidget {
  final TextEditingController _controladorNome = TextEditingController();
  final TextEditingController _controladorEmail = TextEditingController();
  final TextEditingController _controladorTelefone = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cadastrando Contato'),
      ),
      body: Column(
        children: <Widget>[
          TextField( controller: _controladorNome,),
          TextField( controller: _controladorTelefone,),
          TextField( controller: _controladorEmail,),
          ElevatedButton(
            child: Text('Cadastrar'),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) =>  SecoundRoute()),
              );

              final String nome = _controladorNome.text;
              final int? telefone = int.tryParse(_controladorTelefone.text);
              final String email = _controladorEmail.text;
              final Cadastro CadastroNovo = Cadastro(nome, telefone!, email);
              print(CadastroNovo);
              print("Clicked");

            },
          )
        ],
      ),
    );
  }
}

class SecoundRoute extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('New Screen')),
      body: Center(
        child: Text(
          'This is a new screen',
          style: TextStyle(fontSize: 24.0),
        ),
      ),
    );
  }
}
