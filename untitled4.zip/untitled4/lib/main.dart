import 'package:flutter/material.dart';
import 'package:untitled4/cadastro.dart';
import 'package:untitled4/segunda_pag.dart';
import 'package:untitled4/variaveis.dart';

void main() {
  runApp( MyApp());
}

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomeScreen()
    );
  }
}

class SecondRoute extends StatelessWidget {
  final TextEditingController _controladorNome = TextEditingController();
  final TextEditingController _controladorEmail = TextEditingController();
  final TextEditingController _controladorTelefone = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cadastrando Contato'),
      ),
      body: Column(
        children: <Widget>[
          TextField( controller: _controladorNome,),
          TextField( controller: _controladorTelefone,),
          TextField( controller: _controladorEmail,),
          ElevatedButton(
            child: Text('Cadastrar'),
            onPressed: () {
              final String nome = _controladorNome.text;
              final String telefone = _controladorTelefone.text;
              final String email = _controladorEmail.text;
              final  Cadastro CadastroNovo = Cadastro(nome, telefone, email);
              contatos.add(CadastroNovo);
              print(contatos);
            },
          )
        ],
      ),
    );
  }
}
