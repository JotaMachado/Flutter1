class Cadastro {
  final String nome;
  final String telefone;
  final String email;

  Cadastro(this.nome,
      this.telefone,
      this.email,
      );

  @override
  String toString() {
    return 'Cadastro{nome: $nome, telefone: $telefone, email: $email}';
  }
}

